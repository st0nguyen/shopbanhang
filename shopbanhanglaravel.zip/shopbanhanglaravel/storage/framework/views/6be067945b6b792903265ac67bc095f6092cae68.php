<?php $__env->startSection('admin_content'); ?>
<h3>Chào mừng bạn đến với Admin</h3>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('admin_layout', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH D:\xampp\htdocs\shopbanhanglaravel\resources\views/admin/dashboard.blade.php ENDPATH**/ ?>